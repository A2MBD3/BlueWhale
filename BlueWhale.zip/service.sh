#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/proxy_arm64"
PIDFILE="$MODDIR/proxy.pid"
LOG="$MODDIR/debug.log"
HOSTS_MOD="$MODDIR/system/etc/hosts"
HOSTS_REAL="/system/etc/hosts"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

notify() {
  cmd notification post -t "$1" "bluewhale" "$2" >/dev/null 2>&1 || true
}

ensure_hosts_bind() {
  mkdir -p "$(dirname "$HOSTS_MOD")"
  if [ ! -s "$HOSTS_MOD" ]; then
    cat "$HOSTS_REAL" > "$HOSTS_MOD" 2>/dev/null || {
      echo "127.0.0.1 localhost" > "$HOSTS_MOD"
      echo "::1 localhost" >> "$HOSTS_MOD"
    }
  fi
  chmod 644 "$HOSTS_MOD" 2>/dev/null
  if [ -f "$HOSTS_REAL" ]; then
    mount | grep -q " $HOSTS_REAL " || mount --bind "$HOSTS_MOD" "$HOSTS_REAL" 2>/dev/null
  fi
  if [ -f /etc/hosts ] && [ "$(readlink -f /etc/hosts 2>/dev/null)" != "$HOSTS_REAL" ]; then
    mount | grep -q " /etc/hosts " || mount --bind "$HOSTS_MOD" /etc/hosts 2>/dev/null
  fi
}

is_running() {
  local pid=""
  [ -f "$PIDFILE" ] && pid=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    if command -v ss >/dev/null 2>&1; then
      ss -tlnp 2>/dev/null | grep -q ":80 " && return 0
    else
      return 0
    fi
  fi
  return 1
}

kill_all() {
  if [ -f "$PIDFILE" ]; then
    old=$(cat "$PIDFILE" 2>/dev/null)
    [ -n "$old" ] && kill -9 "$old" 2>/dev/null
    rm -f "$PIDFILE"
  fi
  pkill -9 -f "proxy_arm64" 2>/dev/null
  fuser -k 80/tcp 2>/dev/null
  iptables -t nat -D OUTPUT -p tcp --dport 80 -j DNAT --to-destination 127.0.0.1:80 2>/dev/null
  sleep 1
}

start_bin() {
  ensure_hosts_bind
  chmod 755 "$BIN" 2>/dev/null
  [ ! -x "$BIN" ] && { log "ERROR: binary not executable"; return 1; }

  nohup "$BIN" >>"$LOG" 2>&1 &
  local newpid=$!
  echo "$newpid" > "$PIDFILE"
  sleep 2

  if kill -0 "$newpid" 2>/dev/null; then
    log "Started OK (PID $newpid)"
    return 0
  else
    log "ERROR: binary exited immediately"
    rm -f "$PIDFILE"
    return 1
  fi
}

# Boot
sleep 18
log "=== service.sh boot start ==="
ensure_hosts_bind
kill_all

if start_bin; then
  notify "Blue Whale 🐋" "Service started after reboot"
else
  log "First start failed, watchdog will retry"
  notify "Blue Whale 🐋" "Service start failed – watchdog will retry"
fi

# Watchdog
fail_count=0
while true; do
  sleep 12
  if ! is_running; then
    fail_count=$((fail_count + 1))
    log "Watchdog: not running (fail #$fail_count) → restarting"
    kill_all
    if start_bin; then
      fail_count=0
      notify "Blue Whale 🐋" "Service recovered by watchdog"
    else
      log "Watchdog restart failed"
      [ $fail_count -gt 5 ] && sleep 20
    fi
  else
    fail_count=0
  fi
done