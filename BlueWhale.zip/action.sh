#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/BlueWhale"
PIDFILE="$MODDIR/proxy.pid"
LOG="$MODDIR/debug.log"

is_running() {
  [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null
}

echo "Blue Whale Action"
if is_running; then
  echo "Restarting..."
  kill -9 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null
  pkill -f "BlueWhale" 2>/dev/null
  rm -f "$PIDFILE"
  sleep 1
else
  echo "Starting..."
fi

chmod 755 "$BIN"
nohup "$BIN" >>"$LOG" 2>&1 &
echo $! > "$PIDFILE"
sleep 2

if is_running; then
  echo "✓ OK  PID $(cat $PIDFILE) Open Webui again"
else
  echo "✗ Failed"
sleep 2
  tail -n 8 "$LOG" 2>/dev/null
fi