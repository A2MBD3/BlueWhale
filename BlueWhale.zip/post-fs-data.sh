#!/system/bin/sh
MODDIR=${0%/*}
HOSTS_MOD="$MODDIR/system/etc/hosts"
HOSTS_REAL="/system/etc/hosts"

mkdir -p "$(dirname "$HOSTS_MOD")"

if [ ! -s "$HOSTS_MOD" ]; then
  if [ -r "$HOSTS_REAL" ]; then
    cat "$HOSTS_REAL" > "$HOSTS_MOD" 2>/dev/null
  fi
  [ -s "$HOSTS_MOD" ] || {
    echo "127.0.0.1 localhost" > "$HOSTS_MOD"
    echo "::1 localhost" >> "$HOSTS_MOD"
  }
fi

chmod 644 "$HOSTS_MOD" 2>/dev/null

if [ -f "$HOSTS_REAL" ]; then
  mount | grep -q " $HOSTS_REAL " || mount --bind "$HOSTS_MOD" "$HOSTS_REAL" 2>/dev/null
fi

if [ -f /etc/hosts ] && [ "$(readlink -f /etc/hosts 2>/dev/null)" != "$HOSTS_REAL" ]; then
  mount --bind "$HOSTS_MOD" /etc/hosts 2>/dev/null
fi

exit 0