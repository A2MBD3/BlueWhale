#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/proxy_arm64"
PIDFILE="$MODDIR/proxy.pid"
LOG="$MODDIR/debug.log"

sleep 25

start() {
  if [ -f "$PIDFILE" ]; then
    old=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
      return 0
    fi
  fi
  pkill -f "proxy_arm64" 2>/dev/null
  sleep 1
  chmod 755 "$BIN" 2>/dev/null
  nohup "$BIN" >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
}

start

while true; do
  sleep 15
  if [ -f "$PIDFILE" ]; then
    pid=$(cat "$PIDFILE" 2>/dev/null)
    if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
      start
    fi
  else
    start
  fi
done