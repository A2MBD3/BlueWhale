#!/system/bin/sh
ui_print "- Blue Whale 🐋 v3.5"
set_perm $MODPATH/system/bin/proxy_arm64 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
