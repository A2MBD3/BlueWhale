#!/system/bin/sh
ui_print "- Blue Whale 🐋 v3.6 (Systemless + Superstable)"
ui_print "- Hosts via bind-mount (fully systemless)"
ui_print "- Action button: Start / Restart"
ui_print "- Always-on watchdog + notification"

set_perm $MODPATH/system/bin/proxy_arm64 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

mkdir -p $MODPATH/system/etc
if [ ! -s "$MODPATH/system/etc/hosts" ]; then
  if [ -f /system/etc/hosts ]; then
    cat /system/etc/hosts > "$MODPATH/system/etc/hosts"
  else
    echo "127.0.0.1 localhost" > "$MODPATH/system/etc/hosts"
    echo "::1 localhost" >> "$MODPATH/system/etc/hosts"
  fi
fi

ui_print "- Done. Reboot recommended."