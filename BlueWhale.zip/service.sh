#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/proxy_arm64"
PIDFILE="$MODDIR/proxy.pid"

sleep 20

start_it() {
    if [ -f "$PIDFILE" ]; then
        old=$(cat "$PIDFILE" 2>/dev/null)
        [ -n "$old" ] && kill -9 "$old" 2>/dev/null
        rm -f "$PIDFILE"
    fi
    fuser -k 80/tcp 2>/dev/null
    sleep 1
    chmod 755 "$BIN" 2>/dev/null
    nohup "$BIN" >/dev/null 2>&1 &
    echo $! > "$PIDFILE"
}

start_it

while true; do
    sleep 10
    need=0
    if [ ! -f "$PIDFILE" ]; then need=1; fi
    if [ -f "$PIDFILE" ]; then
        pid=$(cat "$PIDFILE" 2>/dev/null)
        if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then need=1; fi
    fi
    if ! ss -tlnp 2>/dev/null | grep -q ':80 '; then need=1; fi
    [ "$need" = "1" ] && start_it
done
