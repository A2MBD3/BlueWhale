#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/proxy_arm64"
PIDFILE="$MODDIR/proxy.pid"
LOG="$MODDIR/debug.log"
HOSTS_MOD="$MODDIR/system/etc/hosts"
HOSTS_REAL="/system/etc/hosts"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [action] $1" >> "$LOG"
}

ensure_hosts_bind() {
  mkdir -p "$(dirname "$HOSTS_MOD")"
  if [ ! -s "$HOSTS_MOD" ]; then
    cat "$HOSTS_REAL" > "$HOSTS_MOD" 2>/dev/null || {
      echo "127.0.0.1 localhost" > "$HOSTS_MOD"
      echo "::1 localhost" >> "$HOSTS_MOD"
    }
  fi
  chmod 644 "$HOSTS_MOD" 2>/dev/null
  if [ -f "$HOSTS_REAL" ]; then
    mount | grep -q " $HOSTS_REAL " || mount --bind "$HOSTS_MOD" "$HOSTS_REAL" 2>/dev/null
  fi
}

is_running() {
  local pid=""
  [ -f "$PIDFILE" ] && pid=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    if command -v ss >/dev/null 2>&1; then
      ss -tlnp 2>/dev/null | grep -q ":80 " && return 0
    else
      return 0
    fi
  fi
  return 1
}

kill_all() {
  if [ -f "$PIDFILE" ]; then
    old=$(cat "$PIDFILE" 2>/dev/null)
    [ -n "$old" ] && kill -9 "$old" 2>/dev/null
    rm -f "$PIDFILE"
  fi
  pkill -9 -f "proxy_arm64" 2>/dev/null
  fuser -k 80/tcp 2>/dev/null
  iptables -t nat -D OUTPUT -p tcp --dport 80 -j DNAT --to-destination 127.0.0.1:80 2>/dev/null
  sleep 1
}

start_bin() {
  ensure_hosts_bind
  chmod 755 "$BIN" 2>/dev/null
  if [ ! -x "$BIN" ]; then
    echo "✗ ERROR: Binary not found or not executable"
    return 1
  fi
  nohup "$BIN" >>"$LOG" 2>&1 &
  local newpid=$!
  echo "$newpid" > "$PIDFILE"
  sleep 2
  if kill -0 "$newpid" 2>/dev/null; then
    return 0
  else
    rm -f "$PIDFILE"
    return 1
  fi
}

echo "Blue Whale 🐋 Action"
echo "-------------------"

if is_running; then
  echo "Status: Running → Restarting..."
  log "Action: Restart requested"
  kill_all
  if start_bin; then
    echo "✓ Service RESTARTED successfully"
    echo "PID: $(cat $PIDFILE 2>/dev/null)"
  else
    echo "✗ FAILED to restart"
    echo "Check debug.log"
    exit 1
  fi
else
  echo "Status: Stopped → Starting..."
  log "Action: Start requested"
  kill_all
  if start_bin; then
    echo "✓ Service STARTED successfully"
    echo "PID: $(cat $PIDFILE 2>/dev/null)"
  else
    echo "✗ FAILED to start"
    echo "Possible: port 80 busy / SELinux / binary crash"
    exit 1
  fi
fi

sleep 1
if is_running; then
  echo "✓ Listening on port 80"
else
  echo "⚠ Process started but port 80 not confirmed yet"
fi
exit 0